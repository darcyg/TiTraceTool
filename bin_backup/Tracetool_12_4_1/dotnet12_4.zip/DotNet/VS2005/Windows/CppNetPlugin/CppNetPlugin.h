// CppNetPlugin.h

#pragma once

using namespace System;

