using System;
using System.Windows.Forms;

namespace PPC
{
    public class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            Application.Run(new PPC2003CF1());
        }
    }
}