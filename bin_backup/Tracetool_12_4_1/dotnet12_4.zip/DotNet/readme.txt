Visual studio 2003 solutions
==============================

   ASP.net
   -------  
      VS2003\Asp.Net\VS7 ASp.net tracetool demo.sln

   Pocket pc 2003 (compact framework1)
   -----------------------------------
      VS2003\PPC2003\PPC2003 CF1 tracetool lib and demo.sln


   Windows libraries and demos
   ---------------------------
      VS2003\Windows\Vs7 Windows TraceTool Dot net Library and Demos.sln
      VS2003\Windows\Vs7 Windows TraceTool EIF Library and demo.sln
      VS2003\Windows\Vs7 Windows TraceTool Log4Net library and demo.sln


Visual studio 2005 solutions
==============================

   ASP.net
   -------
      VS2005\Asp.Net\AspTraces.sln

   Pocket pc 2003 (compact framework1 and 2)
   -----------------------------------------
      VS2005\PPC2003\compact framework 1\PPC2003 CF1 tracetool lib and demo.sln
      VS2005\PPC2003\compact framework 2\Vs8 PPC2003 CF2 tracetool lib and demo.sln

   Windows libraries and demos
   ---------------------------
      VS2005\Windows\Vs8 Windows TraceTool Dot net Library and Demos.sln

