// TraceToSend.CS
//
// Base class (abstract) for TraceNode and Wintrace.
//
// Author : Thierry Parent
// Version : 12.4
//
// HomePage :  http://www.codeproject.com/csharp/TraceTool.asp
// Download :  http://sourceforge.net/projects/tracetool/
// See License.txt for license information
//
// Change the tracetool project option ("conditional compilation constant") to specify the target dot net version :
// NETF1  (dot net framework 1)          , NETF2 ((dot net framework 2) ,
// NETCF1 (dot net compact framework 1)  , NETCF2 (dot net compact framework 2) , NETCF3 (dot net compact framework 3)

using System;
using System.Text;
using System.Collections;  // ArrayList, queue

// generic start in F2
#if (!NETCF1 && !NETF1)
using System.Collections.Generic;
#endif

namespace TraceTool
{

   /// TraceToSend methodes create new traces and send it to the viewer
   /// Common base class for TraceNode and WinTrace
   /// TTrace.warning, debug and error are TraceNode
   public abstract class TraceToSend : TraceNodeBase   // no base constructor
   {

      internal NodeContextList fContextList;              // context list
      internal NodeContextList fWinTraceContext = null;   // reference to winTrace Context (fContextList). Can be null

      /// <summary>
      /// The most useful function to send trace
      /// <example> This sample shows how to send a sample trace.
      /// <code>
      /// TTrace.Debug.Send ("Hello world") ;
      /// </code>
      /// <code>
      /// TraceNode FirstNode ;
      /// FirstNode = TTrace.Debug.Send ("Hello") ;
      /// FirstNode.Send ("World") ;   // add a second node under the first one
      /// </code>
      /// </example>
      /// </summary>
      /// <param name="leftMsg">The message to display in the 'traces' column</param>
      /// <returns>the new node</returns>
      public TraceNode Send(string leftMsg)
      {
         if (Enabled == false)
            return new TraceNode(this);
         // create a node with same properties as "this" with new ID
         TraceNodeEx result = new TraceNodeEx(this, true);
         StringList CommandList = prepareNewNode(leftMsg, result.Id);
         TTrace.SendToWinTraceClient(CommandList, WinTraceId);
         return new TraceNode(result);
      }

      //----------------------------------------------------------------------

      /// <summary>
      /// Send a trace specifying the text for 2 columns
      /// <example> This sample shows how to send a sample trace.
      /// <code>
      /// TTrace.Debug.Send ("Hello", "world") ;  // 2 columns trace
      /// </code>
      /// </example>
      /// </summary>
      /// <param name="leftMsg">The message in the "traces" column</param>
      /// <param name="rightMsg">The message in the "Comment" column</param>
      /// <returns>the new node</returns>
      public TraceNode Send(string leftMsg, string rightMsg)
      {
         if (Enabled == false)
            return new TraceNode(this);
         // create a node with same properties as "this" with new ID
         TraceNodeEx result = new TraceNodeEx(this, true);
         StringList CommandList = prepareNewNode(leftMsg, result.Id);
         if (rightMsg != "")
            Helper.addCommand(CommandList, TraceConst.CST_RIGHT_MSG, rightMsg);    // param : right string

         TTrace.SendToWinTraceClient(CommandList, WinTraceId);
         return new TraceNode(result);
      }

      //----------------------------------------------------------------------
      /// <summary>
      /// Send a 'reflected' representation of the given object
      /// </summary>
      /// <param name="leftMsg">the message to display</param>
      /// <param name="ObjToSend">The object to inspect</param>
      /// <returns>the new node</returns>
      public TraceNode SendObject(string leftMsg, Object ObjToSend)
      {
         // no need to check if enabled, done in the other function
         return SendObject(leftMsg, ObjToSend, TTrace.Options.GetDefault());
      }

      //----------------------------------------------------------------------
      /// <summary>
      /// Send a 'reflected' representation of the given object
      /// </summary>
      /// <param name="leftMsg">the message to display</param>
      /// <param name="ObjToSend">The object to inspect</param>
      /// <param name="flags">what information to display</param>
      /// <returns>the new node</returns>
      public TraceNode SendObject(string leftMsg, Object ObjToSend, TraceDisplayFlags flags)
      {
         Type oType;

         if (Enabled == false)
            return new TraceNode(this);

         if (ObjToSend == null)
            oType = null;
         else
            oType = ObjToSend.GetType();

         TraceNodeEx result = new TraceNodeEx(this, true);  // create a node with same properties as "this" with new ID

         StringList CommandList = prepareNewNode(leftMsg, result.Id);

         // detect null type
         if (oType == null)
         {
            TMemberNode node = new TMemberNode("Null Type");
            node.ViewerKind = TraceConst.CST_VIEWER_OBJECT ;
            result.Members.Add(node);
            result.Members.AddToStringList(CommandList);
            TTrace.SendToWinTraceClient(CommandList, WinTraceId);
            return new TraceNode(result);
         }

         // informations are added to the Members array of the new created object.
         // This current instance can be the public 'Warning' node for example used by multi thread application
         result.AddTypeObject(ObjToSend, oType, flags);
         result.Members.AddToStringList(CommandList);   // convert all groups and nested items/group to strings

         TTrace.SendToWinTraceClient(CommandList, WinTraceId);
         return new TraceNode(result);
      }

      //----------------------------------------------------------------------
      /// <summary>
      /// Send the Value of the given object (useful for base type, variant and array)
      /// properties and array content are also inspected with a maximum
      /// </summary>
      /// <param name="leftMsg">the message to display</param>
      /// <param name="ObjToSend">The object to show</param>
      /// <returns>the new node</returns>
      public TraceNode SendValue(string leftMsg, Object ObjToSend)
      {
         return SendValue(leftMsg, ObjToSend, TTrace.Options.SendPrivate);
      }

      //----------------------------------------------------------------------
      /// <summary>
      /// Send the Value of the given object (useful for base type, variant and array)
      /// </summary>
      /// <param name="leftMsg">the message to display</param>
      /// <param name="ObjToSend">The object to show</param>
      /// <param name="sendPrivate">Send Private fields (default is false)</param>
      /// <returns>the new node</returns>
      public TraceNode SendValue(string leftMsg, Object ObjToSend, bool sendPrivate)
      {
         return SendValue(leftMsg, ObjToSend, sendPrivate, TTrace.Options.ObjectTreeDepth);
      }

      //----------------------------------------------------------------------
      /// <summary>
      /// Send the Value of the given object (useful for base type, variant and array)
      /// </summary>
      /// <param name="leftMsg">the message to display</param>
      /// <param name="ObjToSend">The object to show</param>
      /// <param name="sendPrivate">Send Private fields (default is false)</param>
      /// <param name="maxLevel">Max level to inspect (default is 3)</param>
      /// <returns>the new node</returns>
      public TraceNode SendValue(string leftMsg, Object ObjToSend, bool sendPrivate, int maxLevel)
      {
         string strModifier = "";
         string strName = "";
         try
         {
            if (ObjToSend == null)
            {
               strModifier = "Null Object";
            }
            else
            {
               Type oType = ObjToSend.GetType();
               ReflectionHelper.Type2String(oType, ref strModifier, ref strName);
               if (strModifier != "")
                  strModifier = strModifier + " ";
            }
         }
         catch
         {
            // no error
         }

         return SendValue(leftMsg, ObjToSend, sendPrivate, maxLevel, strModifier + strName);
      }

      //----------------------------------------------------------------------
      /// <summary>
      /// Send the Value of the given object (useful for base type, variant and array)
      /// </summary>
      /// <param name="leftMsg">the message to display</param>
      /// <param name="ObjToSend">The object to show</param>
      /// <param name="sendPrivate">Send Private fields (default is false)</param>
      /// <param name="maxLevel">Max level to inspect (default is 3)</param>
      /// <param name="objTitle">Title of the object</param>
      /// <returns>the new node</returns>
      public TraceNode SendValue(string leftMsg, Object ObjToSend, bool sendPrivate, int maxLevel, string objTitle)
      {

         if (Enabled == false)
            return new TraceNode(this);

         TraceNodeEx result = new TraceNodeEx(this, true);  // create a node with same properties as "this" with new ID
         StringList CommandList = prepareNewNode(leftMsg, result.Id);

         // informations are added to the Members array of the new created object the actual object.
         // This current instance can be the public 'Warning' node for example used by multi thread application
         result.AddValue(ObjToSend, sendPrivate, maxLevel, objTitle);
         result.Members.AddToStringList(CommandList);   // convert all groups and nested items/group to strings

         TTrace.SendToWinTraceClient(CommandList, WinTraceId);
         return new TraceNode(result);
      }

      //----------------------------------------------------------------------

      /// <summary>
      /// Send a 'reflected' representation of the given type
      /// </summary>
      /// <param name="leftMsg">The message to display</param>
      /// <param name="oType">The type to inspect</param>
      /// <returns>the new node</returns>
      public TraceNode SendType(string leftMsg, Type oType)
      {
         // no need to check if enabled, done in the other function
         return SendType(leftMsg, oType, TTrace.Options.GetDefault());
      }

      //----------------------------------------------------------------------

      /// <summary>
      /// Send a 'reflected' representation of the given type
      /// </summary>
      /// <param name="leftMsg">The message to display</param>
      /// <param name="oType">The type to inspect</param>
      /// <param name="flags">flags to limit information to send</param>
      /// <returns>the new node</returns>
      public TraceNode SendType(string leftMsg, Type oType, TraceDisplayFlags flags)
      {
         if (Enabled == false)
            return new TraceNode(this);

         TraceNodeEx result = new TraceNodeEx(this, true);  // create a node with same properties as "this" with new ID

         StringList CommandList = prepareNewNode(leftMsg, result.Id);
         // detect null type
         if (oType == null)
         {
            TMemberNode node = new TMemberNode("Null Type");
            node.ViewerKind = TraceConst.CST_VIEWER_OBJECT;
            result.Members.Add(node);
            result.Members.AddToStringList(CommandList);
            TTrace.SendToWinTraceClient(CommandList, WinTraceId);
            return new TraceNode(result);
         }

         // informations are added to the Members array of the new created object the actual object
         // the current instance can be the public 'Warning' node for example used by multi thread application
         result.AddTypeObject(null, oType, flags);
         result.Members.AddToStringList(CommandList); // convert all groups and nested items/group to strings

         TTrace.SendToWinTraceClient(CommandList, WinTraceId);
         return new TraceNode(result);
      }

      //----------------------------------------------------------------------
#if (!NETCF1 && !NETCF2 && !NETCF3)
      /// <summary>
      /// Send the stack frames.
      /// </summary>
      /// <param name="leftMsg">Trace message</param>
      /// <param name="level">Number of call to skip</param>
      /// <returns>the new node</returns>
      public TraceNode SendStack(string leftMsg, int level)
      {
         if (Enabled == false)
            return new TraceNode(this);

         TraceNodeEx result = new TraceNodeEx(this, true);  // create a node with same properties as "this" with new ID

         StringList CommandList = prepareNewNode(leftMsg, result.Id);


         result.AddStackTrace(level + 1);
         result.Members.AddToStringList(CommandList); // convert all groups and nested items/group to strings

         TTrace.SendToWinTraceClient(CommandList, WinTraceId);
         return new TraceNode(result);
      }

      //----------------------------------------------------------------------
      /// <summary>
      /// Send the caller frame.
      /// </summary>
      /// <param name="leftMsg">Trace message</param>
      /// <param name="level">Level 0 is self</param>
      /// <returns>the new node</returns>
      public TraceNode SendCaller(string leftMsg, int level)
      {
         if (Enabled == false)
            return new TraceNode(this);

         TraceNodeEx result = new TraceNodeEx(this, true);  // create a node with same properties as "this" with new ID

         StringList CommandList = prepareNewNode(leftMsg, result.Id);

         result.AddCaller(level + 1);
         result.Members.AddToStringList(CommandList); // convert all groups and nested items/group to strings

         TTrace.SendToWinTraceClient(CommandList, WinTraceId);
         return new TraceNode(result);
      }

      //------------------------------------------------------------------------------

#if (!SILVERLIGHT)

      /// <summary>
      /// Send a bitmap
      /// </summary>
      /// <param name="leftMsg">Trace message</param>
      /// <param name="image">The Image</param>
      /// <returns>the new node</returns>
      public TraceNode SendBitmap(string leftMsg, System.Drawing.Image image)
      {
         if (Enabled == false)
            return new TraceNode(this);

         TraceNodeEx result = new TraceNodeEx(this, true);  // create a node with same properties as "this" with new ID
         StringList CommandList = prepareNewNode(leftMsg, result.Id);

         result.AddBitmap(image);
         result.Members.AddToStringList(CommandList); // convert all groups and nested items/group to strings

         TTrace.SendToWinTraceClient(CommandList, WinTraceId);
         return new TraceNode(result);
      }
#endif

#endif

// currently not possibe in silverlight 2 : 
// - No way to read the Image content
// - BmpBitmapEncoder is not supported
#if (NETF3) 
      /// <summary>
      /// Send a bitmap
      /// </summary>
      /// <param name="leftMsg">Trace message</param>
      /// <param name="image">The Image</param>
      /// <returns>the new node</returns>
      public TraceNode SendBitmap(string leftMsg, System.Windows.Controls.Image image)
      {
         if (Enabled == false)
            return new TraceNode(this);

         TraceNodeEx result = new TraceNodeEx(this, true);  // create a node with same properties as "this" with new ID
         StringList CommandList = prepareNewNode(leftMsg, result.Id);

         result.AddBitmap(image);
         result.Members.AddToStringList(CommandList); // convert all groups and nested items/group to strings

         TTrace.SendToWinTraceClient(CommandList, WinTraceId);
         return new TraceNode(result);
      }

#endif

      //----------------------------------------------------------------------
      /// <summary>
      /// Send byte dump.
      /// </summary>
      /// <param name="leftMsg">Trace message</param>
      /// <param name="ShortTitle">Tite to display in the first col</param>
      /// <param name="adr">Pointer to the buffer to dump</param>
      /// <param name="count">Number of byte to dump</param>
      /// <returns>the new node</returns>
      public TraceNode SendDump(string leftMsg, string ShortTitle, byte[] adr, int count)
      {
         if (Enabled == false)
            return new TraceNode(this);

         TraceNodeEx result = new TraceNodeEx(this, true);  // create a node with same properties as "this" with new ID
         StringList CommandList = prepareNewNode(leftMsg, result.Id);

         result.AddDump(ShortTitle, adr, 0, count);
         result.Members.AddToStringList(CommandList); // convert all groups and nested items/group to strings

         TTrace.SendToWinTraceClient(CommandList, WinTraceId);
         return new TraceNode(result);
      }

      //----------------------------------------------------------------------
      /// <summary>
      /// send trace with a specific background color
      /// </summary>
      /// <param name="leftMsg">Trace message</param>
      /// <param name="color">RGB background color (see Color.ToArgb function)</param>
      /// <returns>the new node</returns>
      public TraceNode SendBackgroundColor(string leftMsg, int color)
      {
         if (Enabled == false)
            return new TraceNode(this);

         TraceNodeEx result = new TraceNodeEx(this, true);  // create a node with same properties as "this" with new ID
         StringList CommandList = prepareNewNode(leftMsg, result.Id);
         Helper.addCommand(CommandList, TraceConst.CST_BACKGROUND_COLOR, Helper.ARGB_to_BGR(color), "-1");      // param : color, colId

         TTrace.SendToWinTraceClient(CommandList, WinTraceId);
         return new TraceNode(result);
      }

      //------------------------------------------------------------------------------

      /// <summary>
      /// send trace with a specific background color
      /// </summary>
      /// <param name="leftMsg">Trace message</param>
      /// <param name="color">RGB background color (see Color.ToArgb function)</param>
      /// <param name="colId">Column index : All columns= -1,Icon=0, Time=1, thread=2, left msg=3, right msg =4 or user defined column</param>
      /// <returns>the new node</returns>
      public TraceNode SendBackgroundColor(string leftMsg, int color, int colId) // = -1
      {
         if (Enabled == false)
            return new TraceNode(this);

         TraceNodeEx result = new TraceNodeEx(this, true);  // create a node with same properties as "this" with new ID
         StringList CommandList = prepareNewNode(leftMsg, result.Id);
         Helper.addCommand(CommandList, TraceConst.CST_BACKGROUND_COLOR, Helper.ARGB_to_BGR(color), colId.ToString());      // param : color, colId

         TTrace.SendToWinTraceClient(CommandList, WinTraceId);
         return new TraceNode(result);
      }

      //------------------------------------------------------------------------------

      /// <summary>
      /// Send xml text
      /// </summary>
      /// <param name="leftMsg">Trace message</param>
      /// <param name="xml">xml text to send</param>
      /// <returns>the new node</returns>
      public TraceNode SendXml(string leftMsg, string xml)
      {
         if (Enabled == false)
            return new TraceNode(this);

         TraceNodeEx result = new TraceNodeEx(this, true);  // create a node with same properties as "this" with new ID
         StringList CommandList = prepareNewNode(leftMsg, result.Id);

         result.AddXML(xml);
         result.Members.AddToStringList(CommandList); // convert all groups and nested items/group to strings

         TTrace.SendToWinTraceClient(CommandList, WinTraceId);
         return new TraceNode(result);
      }

      //------------------------------------------------------------------------------

      /// <summary>
      /// Add table to node
      /// </summary>
      /// <param name="leftMsg">Trace message</param>
      /// <param name="table">table to send</param>
      /// <returns>the new node</returns>
      public TraceNode SendTable(string leftMsg, TraceTable table)
      {
         if (Enabled == false)
            return new TraceNode(this);

         TraceNodeEx result = new TraceNodeEx(this, true);  // create a node with same properties as "this" with new ID
         StringList CommandList = prepareNewNode(leftMsg, result.Id);

         result.AddTable(table);
         result.Members.AddToStringList(CommandList); // convert all groups and nested items/group to strings

         TTrace.SendToWinTraceClient(CommandList, WinTraceId);
         return new TraceNode(result);
      }

      //------------------------------------------------------------------------------
      
      /// <summary>
      /// Add table to node
      /// </summary>
      /// <param name="leftMsg">Trace message</param>
      /// <param name="table">Object table to send. Must be an Array or IEnumerable or IDictionary</param>
      /// <returns>the new node</returns>
      public TraceNode SendTable(string leftMsg, Object table)
      {
         if (Enabled == false)
            return new TraceNode(this);

         TraceNodeEx result = new TraceNodeEx(this, true);  // create a node with same properties as "this" with new ID
         StringList CommandList = prepareNewNode(leftMsg, result.Id);

         result.AddTable(table);
         result.Members.AddToStringList(CommandList); // convert all groups and nested items/group to strings

         TTrace.SendToWinTraceClient(CommandList, WinTraceId);
         return new TraceNode(result);
      }
      /*
       * The code is not necessary, because the "SendTable(string leftMsg, Object table)" perform the same job : IEnumerable<T> inherit from IEnumerable
      #if (!NETCF1 && !NETF1)
            /// <summary>
            /// Add table to node
            /// </summary>
            /// <param name="leftMsg">Trace message</param>
            /// <param name="table">IEnumerable Object table to send.</param>
            /// <returns>the new node</returns>
            public TraceNode SendTable<T>(string leftMsg, IEnumerable<T> table)
            {
               if (Enabled == false)
                  return new TraceNode(this);

               TraceNodeEx result = new TraceNodeEx(this, true);  // create a node with same properties as "this" with new ID
               StringList CommandList = prepareNewNode(leftMsg, result.Id);

               result.AddTable<T>(table);
               result.Members.AddToStringList(CommandList); // convert all groups and nested items/group to strings

               TTrace.SendToWinTraceClient(CommandList, WinTraceId);
               return new TraceNode(result);
            }
      #endif
       * */

      //----------------------------------------------------------------------

      /// Prepare the commandList. Common to all SendXXX function
      internal StringList prepareNewNode(string leftMsg, string newId)
      {
         StringList CommandList = new StringList();
         //addCommand (CommandList, TraceConst.CST_NEW_NODE, Id) ;           // param : parent Node id
         Helper.addCommand(CommandList, TraceConst.CST_NEW_NODE, GetLastContextId());           // param : parent Node id
         Helper.addCommand(CommandList, TraceConst.CST_TRACE_ID, newId);        // param : guid
         Helper.addCommand(CommandList, TraceConst.CST_LEFT_MSG, leftMsg);        // param : left string
         if (IconIndex != -1)
            Helper.addCommand(CommandList, TraceConst.CST_ICO_INDEX, IconIndex);
         return CommandList;
      }
      //----------------------------------------------------------------------

      /**
      * Get the last context.
      * @return last context for the thread
      */
      internal NodeContext GetLastContext()
      {
         NodeContextList cList;

         if (fWinTraceContext != null)
            cList = fWinTraceContext;
         else if (fContextList != null)
            cList = fContextList;
         else
            return null ;

         if (cList.Count == 0)
            return null ;
         string thId = Helper.GetCurrentThreadId();
         lock (cList)
         {
            foreach (NodeContext aContext in cList)
            {
               if (aContext.threadId == thId)
                  return aContext;
            }
         }
         return null;
      }

      //------------------------------------------------------------------------------
      /**
      * Get the last context ID.
      * @return last context ID for the thread
      */
      internal string GetLastContextId()
      {
         NodeContext aContext = GetLastContext();
         if (aContext == null)
            return this.Id;
         else
            return aContext.nodeId;
      }

      //------------------------------------------------------------------------------

      /**
      * Save the context
      * @param newContext the context to push
      */
      internal void PushContext(NodeContext newContext)
      {
         NodeContextList cList;

         if (fWinTraceContext != null)
            cList = fWinTraceContext;
         else if (fContextList != null)
            cList = fContextList;
         else
         {
            fContextList = new NodeContextList();
            cList = fContextList;
         }

         lock (cList)
         {
            cList.Insert(0, newContext);
         }
      }

      //------------------------------------------------------------------------------
      /**
       * Delete the last context for the thread
       */
      internal void DeleteLastContext()
      {
         NodeContextList cList;
         if (fWinTraceContext != null)
            cList = fWinTraceContext;
         else if (fContextList != null)
            cList = fContextList;
         else
            return ;

         string thId = Helper.GetCurrentThreadId();
         lock (cList)
         {
            foreach (NodeContext aContext in cList)
            {
               if (aContext.threadId == thId)
               {
                  cList.Remove(aContext);   // no problem with cList iterator, since the function return after delete
                  return;
               }
            }
         }
      }

      //------------------------------------------------------------------------------
      /// <summary>
      /// return current indent level. See Indent()
      /// </summary>
      /// <returns>current indent level</returns>
      public int IndentLevel
      {
         get
         {
            NodeContextList cList;

            if (fWinTraceContext != null)
               cList = fWinTraceContext;
            else if (fContextList != null)
               cList = fContextList;
            else
               return 0;

            // no need to lock an empty list
            if (cList.Count == 0)
               return 0;

            string thId = Helper.GetCurrentThreadId();
            int result = 0 ;
            lock (cList)
            {
               foreach (NodeContext aContext in cList)
               {
                  if (aContext.threadId == thId)
                     result++;
               }
            }
            return result;
         }
      }

      //------------------------------------------------------------------------------
      /// <summary>
      /// Send a message. further trace to the same node are indented under this one.
      /// </summary>
      /// <param name="leftMsg">Left message to send</param>
      public void Indent (string leftMsg)
      {
         Indent (leftMsg,null,-1,false) ;
      }

      //------------------------------------------------------------------------------

      /// <summary>
      /// Send a message. further trace to the same node are indented under this one.
      /// </summary>
      /// <param name="leftMsg">Left message to send</param>
      /// <param name="rightMsg">Right message to send</param>
      public void Indent (string leftMsg, string rightMsg)
      {
         Indent(leftMsg, rightMsg, -1, false);
      }
      //------------------------------------------------------------------------------

      /// <summary>
      /// Send a message. further trace to the same node are indented under this one.
      /// </summary>
      /// <param name="leftMsg">Left message to send</param>
      /// <param name="rightMsg">Right message to send</param>
      /// <param name="BackGroundColor">RGB BackGround Color (see Color.ToArgb function)</param>
      public void Indent(string leftMsg, string rightMsg, int BackGroundColor)
      {
         Indent(leftMsg, rightMsg, BackGroundColor, false);
      }

      //------------------------------------------------------------------------------

      /// <summary>
      /// Send a message. further trace to the same node are indented under this one.
      /// </summary>
      /// <param name="leftMsg">Left message to send</param>
      /// <param name="rightMsg">Right message to send</param>
      /// <param name="BackGroundColor">BackGround Color</param>
      /// <param name="IsEnter">if true , a special "enter" icon is added on the node</param>
      public void Indent(string leftMsg, string rightMsg, int BackGroundColor, bool IsEnter)
      {
         if (Enabled == false)
            return ;
         string thId = Helper.GetCurrentThreadId();


         NodeContext newContext = new NodeContext() ;
         newContext.threadId = thId ;
         newContext.nodeId = Helper.NewGuid().ToString();
         StringList commandList = new StringList();
         NodeContext lastContext = GetLastContext();
         if (lastContext == null)
         {
            //newContext.level = 1 ;
            Helper.addCommand(commandList, TraceConst.CST_NEW_NODE, this.Id);              // param : parent Node id
         }
         else
         {  // context already exist
            //newContext.level = lastContext.level + 1 ;
            Helper.addCommand(commandList, TraceConst.CST_NEW_NODE, lastContext.nodeId);   // param : parent Node id
         }

         Helper.addCommand(commandList, TraceConst.CST_TRACE_ID, newContext.nodeId);   // param : Node Id
         Helper.addCommand(commandList, TraceConst.CST_LEFT_MSG, leftMsg);              // param : left string

         if (rightMsg != null && rightMsg != "")
            Helper.addCommand(commandList, TraceConst.CST_RIGHT_MSG, rightMsg);        // param : right string

         if (BackGroundColor != -1)
            Helper.addCommand(commandList, TraceConst.CST_BACKGROUND_COLOR, Helper.ARGB_to_BGR(BackGroundColor), "-1");      // param : color, colId

         if (IsEnter)
         {
            TMemberNode member = new TMemberNode();                     // create root member
            member.Add("").ViewerKind = TraceConst.CST_VIEWER_ENTER;    // then add an empty member with special viewer
            member.AddToStringList(commandList);                        // convert all groups and nested items/group to strings
         }

         Helper.addCommand(commandList, TraceConst.CST_ICO_INDEX, IconIndex);          // param : icon index
         TTrace.SendToWinTraceClient(commandList, this.WinTraceId);

         PushContext(newContext) ;
      }

      //------------------------------------------------------------------------------

      /// <summary>
      /// Delete indentation to the node added by indent()
      /// </summary>
      public void UnIndent()
      {
         if (Enabled == false)
            return ;
         DeleteLastContext();
      }
      //----------------------------------------------------------------------

      /// <summary>
      /// Delete indentation to the node added by indent()
      /// </summary>
      /// <param name="leftMsg">Message to send to close indentation (optional)</param>
      public void UnIndent(String leftMsg)
      {
         if (Enabled == false)
            return ;
         UnIndent(leftMsg, "", -1, false);
      }

      //------------------------------------------------------------------------------

      /// <summary>
      /// Delete indentation to the node added by indent()
      /// </summary>
      /// <param name="leftMsg">Message to send to close indentation (optional)</param>
      /// <param name="rightMsg">Message to send to close indentation (optional)</param>
      public void UnIndent(String leftMsg, String rightMsg)
      {
         if (Enabled == false)
            return ;
         UnIndent(leftMsg, rightMsg, -1, false);
      }

      //------------------------------------------------------------------------------

      /// <summary>
      /// Delete indentation to the node added by indent()
      /// </summary>
      /// <param name="leftMsg">Message to send to close indentation (optional)</param>
      /// <param name="rightMsg">Message to send to close indentation (optional)</param>
      /// <param name="BackGroundColor">RGB background color (optional)(see Color.ToArgb function)</param>
      public void UnIndent(String leftMsg, String rightMsg, int BackGroundColor)
      {
         if (Enabled == false)
            return;
         UnIndent(leftMsg, rightMsg, BackGroundColor, false);
      }


      //------------------------------------------------------------------------------

      /// <summary>
      /// Delete indentation to the node added by indent()
      /// </summary>
      /// <param name="leftMsg">Message to send to close indentation (optional)</param>
      /// <param name="rightMsg">Message to send to close indentation (optional)</param>
      /// <param name="BackGroundColor">RGB background color (optional)(see Color.ToArgb function)</param>
      /// <param name="isExit">if true, viewer type 'exit' is used</param>
      public void UnIndent(String leftMsg, String rightMsg, int BackGroundColor, bool isExit)
      {
         if (Enabled == false)
            return;

         DeleteLastContext();

         if (leftMsg != null || rightMsg != null)
         {
            String nodeId = Helper.NewGuid().ToString();  // then give new ID

            StringList CommandList = prepareNewNode(leftMsg,nodeId );

            if (rightMsg != null)
               Helper.addCommand(CommandList, TraceConst.CST_RIGHT_MSG, rightMsg);    // param : right string

            if (BackGroundColor != -1)
               Helper.addCommand(CommandList, TraceConst.CST_BACKGROUND_COLOR, Helper.ARGB_to_BGR(BackGroundColor), "-1");      // param : color, colId

            if (isExit)
            {
               TMemberNode member = new TMemberNode();                     // create root member
               member.Add("").ViewerKind = TraceConst.CST_VIEWER_EXIT;     // then add an empty member with special viewer
               member.AddToStringList(CommandList);                        // convert all groups and nested items/group to strings
            }
            TTrace.SendToWinTraceClient(CommandList, WinTraceId);
         }
      }

      //------------------------------------------------------------------------------

      /// <summary>
      /// Indent with "Enter " + left message + right message (optional) + background color (optional)
      /// </summary>
      /// <param name="leftMsg">Left message to send</param>
      public void EnterMethod(String leftMsg)
      {
         Indent("Enter " + leftMsg, null, -1, true);
      }

      //------------------------------------------------------------------------------

      /// <summary>
      /// Indent with "Enter " + left message + right message (optional) + background color (optional)
      /// </summary>
      /// <param name="leftMsg">Left message to send</param>
      /// <param name="rightMsg">Right message to send</param>
      public void EnterMethod (String leftMsg , String rightMsg )  // : TColor = clBlack
      {
         Indent("Enter " + leftMsg, rightMsg, -1, true);
      }

      //------------------------------------------------------------------------------

      /// <summary>
      /// Indent with "Enter " + left message + right message (optional) + background color (optional)
      /// </summary>
      /// <param name="leftMsg">Left message to send</param>
      /// <param name="rightMsg">Right message to send</param>
      /// <param name="BackGroundColor">RGB BackGround Color(see Color.ToArgb function)</param>
      public void EnterMethod (String leftMsg , String rightMsg , int BackGroundColor)
      {
         Indent("Enter " + leftMsg, rightMsg, BackGroundColor, true);
      }

      //------------------------------------------------------------------------------

      /// <summary>
      /// UnIndent with "Exit " + left message (optional) + right message (optional) + background color (optional)
      /// </summary>
      public void ExitMethod()
      {
         UnIndent("Exit" , null, -1, true);
      }

      //------------------------------------------------------------------------------

      /// <summary>
      /// UnIndent with "Exit " + left message (optional) + right message (optional) + background color (optional)
      /// </summary>
      /// <param name="leftMsg">Left message to send</param>
      public void ExitMethod  (String leftMsg)
      {
         UnIndent("Exit " + leftMsg, null, -1, true);
      }

      //------------------------------------------------------------------------------

      /// <summary>
      /// UnIndent with "Exit " + left message (optional) + right message (optional) + background color (optional)
      /// </summary>
      /// <param name="leftMsg">Left message to send</param>
      /// <param name="rightMsg">Right message to send</param>
      public void ExitMethod  (String leftMsg , String rightMsg)
      {
         UnIndent("Exit " + leftMsg, rightMsg, -1, true);
      }

      //------------------------------------------------------------------------------

      /// <summary>
      /// UnIndent with "Exit " + left message (optional) + right message (optional) + background color (optional)
      /// </summary>
      /// <param name="leftMsg">Left message to send</param>
      /// <param name="rightMsg">Right message to send</param>
      /// <param name="BackGroundColor">RGB BackGround Color(see Color.ToArgb function)</param>
      public void ExitMethod  (String leftMsg , String rightMsg , int BackGroundColor)
      {
         UnIndent("Exit " + leftMsg, rightMsg, BackGroundColor,true);
      }

   }     // TraceNode class

   //----------------------------------------------------------------------
   // InternalUse. Used to remind indentation node id

   internal class NodeContext
   {
      public string threadId;
      public String nodeId;
   }

   //----------------------------------------------------------------------

}
