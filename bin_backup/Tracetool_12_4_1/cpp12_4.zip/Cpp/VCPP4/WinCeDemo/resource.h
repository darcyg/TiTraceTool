//{{NO_DEPENDENCIES}}
// Microsoft eMbedded Visual C++ generated include file.
// Used by WinCeDemo.rc
//
#define IDD_WINCEDEMO_DIALOG            102
#define IDD_SHEET                       102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MENUBAR1                    104
#define IDM_FILEINFO                    111
#define IDR_MAINFRAME                   128
#define IDD_BASIC                       129
#define IDD_NODEEX                      130
#define IDD_MULTIPAGES                  131
#define IDR_MENUBAR                     132
#define IDM_MENUBAR1                    133
#define IDD_WATCH                       137
#define IDSAMPLE1                       1000
#define IDC_SAMPLE1                     1000
#define IDC_START1                      1001
#define IDC_MULTICOL                    1002
#define IDC_INDENT                      1003
#define IDC_MAINSAVETEXT                1004
#define IDC_MAINSAVETOXML               1005
#define IDC_MAINLOADXML                 1006
#define IDC_SHOWVIEWER                  1007
#define IDC_MAINCLEAR                   1008
#define IDC_RESEND                      1009
#define IDC_SETSELECTED                 1010
#define IDC_START2                      1011
#define IDC_APPEND                      1012
#define IDC_SHOWNODE                    1013
#define IDC_NEWWIN                      1014
#define IDC_DISPLAYWIN                  1015
#define IDC_SAYHELLO                    1016
#define IDC_SAVETEXT                    1017
#define IDC_SAVETOXML                   1018
#define IDC_LOADXML                     1019
#define IDC_SEND                        1020
#define IDC_CLEAR                       1021
#define IDC_DISP                        1022
#define IDC_CREATE                      1023
#define IDC_WINWATCH_CREATE             1023
#define IDC_WINWATCH_SEND               1024
#define IDC_WINWATCH_CLEAR              1025
#define IDC_WINWATCH_DISPLAY            1026
#define ID_MENUITEM32771                32771
#define IDS_CAP_MENUITEM32772           32773
#define IDS_CAP_FILE                    32775
#define IDM_FILE_EXIT                   40002
#define IDM_SAVE                        40004
#define IDM_OPEN                        40005
#define ID_FILE                         40008
#define IDM_PLAYFILE                    40012
#define ID_FILE_EXIT                    40020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
