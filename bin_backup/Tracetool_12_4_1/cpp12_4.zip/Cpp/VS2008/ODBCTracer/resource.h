//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ODBCTracer.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ODBCTRACER_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDI_ICON_TASKBAR                130
#define IDR_MENU1                       131
#define IDR_POPUP_MENU                  131
#define IDD_DIALOG_OPTIONS              132
#define IDB_BITMAP_W3L                  133
#define IDC_EDIT_DSN                    1000
#define IDC_EDIT_DESC                   1001
#define IDC_EDIT_SERVER                 1002
#define IDC_EDIT_USER                   1003
#define IDC_EDIT_PASSWORD               1004
#define IDC_EDIT_JVMPARAM               1005
#define IDC_BUTTON_TESTCONNECT          1006
#define IDC_BUTTON_HELP                 1007
#define IDC_EDIT_OUT                    1008
#define IDC_CHECK_LOGFILE               1010
#define IDC_STATIC_LOGFILE              1011
#define IDC_BUT_CLEAR                   1012
#define IDC_STATIC_W3L_DE2              1013
#define IDC_STATIC_W3L_DE               1015
#define IDC_BUT_OPENBROWSER             1017
#define ID_POPUP_SHOWODBCTRACERDIALOG   40001
#define ID_POPUP_OPTIONS                40002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
