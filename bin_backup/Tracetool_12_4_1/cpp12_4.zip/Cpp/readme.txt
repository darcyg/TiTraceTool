Visual C++ 4.0 solutions
========================

   Windows ce and pocket pc 2003 libraries and demo
   ------------------------------------------------
      VCPP4\VCPP4 WinCe TraceTool Lib and Demo.vcw


Visual studio 2003 solutions
============================

   Windows libraries and demos
   ---------------------------
      VS2003\VS7 TraceTool Cpp Win32 Library and Demos.sln


Visual studio 2005 solutions
============================

   Pocket pc 2003 libraries and demo
   ---------------------------------
      VS2005\VS8 TraceTool Cpp PPC2003 Library and Demos.sln
      VS2005\VS8 TraceTool Cpp Win32 Library and Demos.sln
