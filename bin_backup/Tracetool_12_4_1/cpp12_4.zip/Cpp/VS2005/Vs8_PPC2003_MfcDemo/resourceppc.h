//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by VS8_PPC2003Mfc_Demo.rc
//
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDR_MAINFRAME                   128
#define IDR_VS8_PPC2003_MFCTYPE         129
#define IDD_BASIC                       130
#define IDD_MULTIPAGES                  132
#define IDD_NODEEX                      133
#define IDD_WATCHES                     134
#define IDD_ABOUTBOX_WIDE               200
#define IDC_STATIC_1                    201
#define IDC_STATIC_2                    202
#define IDC_STATIC_3                    203
#define IDS_NEW                         301
#define IDS_MENU                        302
#define IDM_NEW                         401
#define IDM_MENU                        402
#define IDC_TAB1                        1000
#define IDC_SAMPLE                      1000
#define IDC_INDENT                      1002
#define IDC_MAINSAVETEXT                1003
#define IDC_MAINSAVETOXML               1004
#define IDC_MAINLOADXML                 1005
#define IDC_SHOWVIEWER                  1006
#define IDC_MAINCLEAR                   1007
#define IDC_START1                      1007
#define IDC_RESEND                      1008
#define IDC_PARTNER                     1008
#define IDC_SETSELECTED                 1009
#define IDC_BUTTON2                     1009
#define IDC_HOSTS                       1009
#define IDC_START2                      1010
#define IDC_APPEND                      1011
#define IDC_SHOWNODE                    1013
#define IDC_NEWWIN                      1014
#define IDC_DISPLAYWIN                  1015
#define IDC_SAYHELLO                    1016
#define IDC_MULTICOL                    1017
#define IDC_SAVETEXT                    1018
#define IDC_SAVETOXML                   1019
#define IDC_LOADXML                     1020
#define IDC_INDENT2                     1021
#define IDC_butWatch                    1022
#define IDC_butClearWatchWindow         1023
#define IDC_butDisplayWatchWindow       1024
#define IDC_butCreateWinWatch           1025
#define IDC_butWinWatchSend             1026
#define IDC_butWinWatchClear            1027
#define IDC_butWinWatchDisplay          1028

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
