In order to execute the demo, you must change the classpath to add Log4J (if you use it)
See the JavaDemo.bat file




