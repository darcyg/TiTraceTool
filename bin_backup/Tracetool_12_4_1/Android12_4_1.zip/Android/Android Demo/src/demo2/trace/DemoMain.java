package demo2.trace;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import android.tracetool.SendMode;
import android.tracetool.TTrace;
import android.tracetool.TraceDisplayFlags;
import android.app.ListActivity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import demo2.trace.R; 

public class DemoMain extends ListActivity 
{
  
   DemoMain me = this ;
   
    // -------------------------------------------------------   
    public class IPString {
       String interfaceDisplayName ;
       String inetAddress ;
       String Loopback ;
    }
    
    // -------------------------------------------------------   
    
    // used to display ip adress into view
    public class IpAdapter extends ArrayAdapter<IPString> {
       
       int resource; 
       //String response;
       //Context context;
       
       //Initialize adapter
       public IpAdapter(Context context, int resource, List<IPString> items) {
           super(context, resource, items);
           this.resource=resource;

       }

       @Override
       public View getView(int position, View convertView, ViewGroup parent)
       {
           LinearLayout ipView;
           //Get the current object
           IPString ip = getItem(position);

           //Inflate the view
           if(convertView==null)
           {
               ipView = new LinearLayout(getContext());
               String inflater = Context.LAYOUT_INFLATER_SERVICE;
               LayoutInflater vi;
               vi = (LayoutInflater)getContext().getSystemService(inflater);
               vi.inflate(resource, ipView, true);
           }
           else
           {
               ipView = (LinearLayout) convertView;
           }
           //Get the text boxes from the listitem.xml file
           TextView interfaceDisplayName = (TextView)ipView.findViewById(R.id.interfaceDisplayName);
           TextView inetAddress          = (TextView)ipView.findViewById(R.id.inetAddress);


           //Assign the appropriate data from our alert object above
           interfaceDisplayName.setText(ip.interfaceDisplayName + " " + ip.Loopback);
           inetAddress.setText(ip.inetAddress);

           return ipView;
       }

    }

    // -------------------------------------------------------   
   
    private Button mButGetIp;
    private Button mButton_tracetool_test; 
    private Button mButton_ClientMode;
    
    private ListView mListView ;
    private EditText mTargetIp ;
   
    public int counter = 0 ;
    public ArrayList<String> IpList ;
    public ArrayList<IPString> InetAddressList ;
    IpAdapter IpArrayAdapter;
   
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        try
        {
           setContentView(R.layout.main);   // 
        } catch (Exception ex) {
           Log.e("ip", ex.toString());
        }   

        mButGetIp = (Button) findViewById(R.id.butGetIp);
        mListView = (ListView) findViewById(android.R.id.list);
        mButton_tracetool_test = (Button) findViewById(R.id.Button_tracetool_test);
        mTargetIp = (EditText) findViewById(R.id.TargetIp); 
        mButton_ClientMode= (Button) findViewById(R.id.Button_ClientMode); 
        
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        
        mButGetIp.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	ButGetIp_click(v) ;
            }
        });

        mButton_ClientMode.setOnClickListener(new View.OnClickListener() {
           public void onClick(View v) {              
              TTrace.options.socketHost = mTargetIp.getText().toString() ;
              TTrace.options.sendMode = SendMode.Socket ;
           }
        });
        

        mButton_tracetool_test.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
               
               ButGetIp_click(v) ;   // ensure we have the InetAddressList table
               counter++ ;
               TTrace.options.socketHost = mTargetIp.getText().toString() ;
               TTrace.debug().send("counter : " + Integer.toString(counter));
          
               int flags = TraceDisplayFlags.showModifiers + 
                           TraceDisplayFlags.showClassInfo +
                           TraceDisplayFlags.showFields +
                           TraceDisplayFlags.showInheritedMembers +
                           TraceDisplayFlags.showMethods +
                           TraceDisplayFlags.showNonPublic;

               
               //Context appcontext = getApplicationContext() ;
               TTrace.debug().send("Traces from demo program") ;
               TTrace.debug().sendObject("this", this,flags) ;
               TTrace.warning().send("More traces ...") ;
               TTrace.debug().sendObject("me object : Full info (take a long time to extract info)", me,flags) ;
               TTrace.debug().sendObject("me object : Only public field (faster)", me) ;
               TTrace.debug().sendValue ("me value  : public fields and sub elements details", me) ;
               TTrace.debug().sendTable("table", InetAddressList) ;               
               byte [] dump = new byte[256] ;
               for (int c = 0 ; c <= 255 ; c++)
                  dump[c] = (byte) c ;               
               TTrace.debug().sendDump("dump", "all chars", dump, 256) ;
            }
        });
        
        mListView.setChoiceMode(ListView.CHOICE_MODE_SINGLE) ;
    }
    
    protected void onDestroy()
    {
       super.onDestroy();
       TTrace.closeSocket() ;
    }


    // get all ip
    public void ButGetIp_click(View v)
    {
       //String result = "" ;
       IpList = new ArrayList<String>() ;
       InetAddressList = new ArrayList<IPString>() ;
       try {
          for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements();) {
             NetworkInterface intf = en.nextElement();
             for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements();) {
                InetAddress inetAddress = enumIpAddr.nextElement();
                
                IPString iPString = new IPString() ;
                InetAddressList.add(iPString) ;
                
                iPString.interfaceDisplayName = intf.getDisplayName() ;
                iPString.inetAddress = inetAddress.getHostAddress().toString() ;

                String adr = intf.getDisplayName() + ":" + inetAddress.getHostAddress().toString() ;  // +"\n"
                if (!inetAddress.isLoopbackAddress()) {
                   IpList.add(adr + "(Loopback)") ;	
                   iPString.Loopback =  "(Loopback)";
                } else {
                   IpList.add(adr) ;	
                   iPString.Loopback = "" ;
                }
             }
	        }
	    } catch (SocketException ex) {
	    	IpList.add(ex.toString()) ;
	    	//mTextView01.setText(ex.toString());
	    	Log.e("ip", ex.toString());
	    }   
	    
       IpArrayAdapter = new IpAdapter(DemoMain.this, R.layout.ip_row2,InetAddressList);
       setListAdapter(IpArrayAdapter);    // mListView.setAdapter
    
  
       //ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.ip_row  , R.id.ip_text ,IpList);
       //ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,IpList);
       //ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_single_choice,IpList);

       //setListAdapter(adapter);    // mListView.setAdapter

    }
    
    
    @Override  
    protected void onListItemClick(ListView l, View v, int position, long id)
    { 
         super.onListItemClick(l, v, position, id);
         mListView.setSelection (position) ;
         ListViewOnItemSelected(l,v,position,id) ;
    }
    
    public void ListViewOnItemSelected (AdapterView<?> parent, View view, int position, long i)
    {
       //Toast.makeText(this, "position: "+position, Toast.LENGTH_SHORT).show();
       mTargetIp.setText(InetAddressList.get(position).inetAddress );         
    }

}


