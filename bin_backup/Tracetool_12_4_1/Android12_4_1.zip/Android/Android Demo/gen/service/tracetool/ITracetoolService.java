/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: C:\\Tracetool\\Android\\Src\\src\\service\\tracetool\\ITracetoolService.aidl
 */
package service.tracetool;
/**
 * Tracetool service. Multiple applications can write traces to the service (running in another process).
 */
public interface ITracetoolService extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements service.tracetool.ITracetoolService
{
private static final java.lang.String DESCRIPTOR = "service.tracetool.ITracetoolService";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an service.tracetool.ITracetoolService interface,
 * generating a proxy if needed.
 */
public static service.tracetool.ITracetoolService asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = (android.os.IInterface)obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof service.tracetool.ITracetoolService))) {
return ((service.tracetool.ITracetoolService)iin);
}
return new service.tracetool.ITracetoolService.Stub.Proxy(obj);
}
public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_sendToViewer:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
this.sendToViewer(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_nbMessToSend:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.nbMessToSend();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_nbMessSent:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.nbMessSent();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_nbMessReceived:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.nbMessReceived();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_getStatus:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.getStatus();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_clearWaitingList:
{
data.enforceInterface(DESCRIPTOR);
this.clearWaitingList();
reply.writeNoException();
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements service.tracetool.ITracetoolService
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
public void sendToViewer(java.lang.String commandList) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(commandList);
mRemote.transact(Stub.TRANSACTION_sendToViewer, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
public int nbMessToSend() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_nbMessToSend, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int nbMessSent() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_nbMessSent, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int nbMessReceived() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_nbMessReceived, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public java.lang.String getStatus() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getStatus, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public void clearWaitingList() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_clearWaitingList, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
}
static final int TRANSACTION_sendToViewer = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_nbMessToSend = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_nbMessSent = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_nbMessReceived = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_getStatus = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_clearWaitingList = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
}
public void sendToViewer(java.lang.String commandList) throws android.os.RemoteException;
public int nbMessToSend() throws android.os.RemoteException;
public int nbMessSent() throws android.os.RemoteException;
public int nbMessReceived() throws android.os.RemoteException;
public java.lang.String getStatus() throws android.os.RemoteException;
public void clearWaitingList() throws android.os.RemoteException;
}
